import pygame
import random

pygame.init()

class Bomb(pygame.sprite.Sprite):
    bomb_img = pygame.image.load("data/bomb.png")
    boom_img = pygame.image.load("data/boom.png")
    def __init__(self, width = 400, height = 400):
        super().__init__()

        self.maxWidtth = width
        self.maxHeight = height

        self.loadBomb()

    def drawBomb(self, surface: pygame.surface.Surface):
        self.sprite.blit(surface)

    def update(self):
        self.rect = self.rect.move(random.randrange(3) - 1, random.randrange(3) - 1)
        
    def loadBomb(self):
        self.image = Bomb.bomb_img
        self.image.set_colorkey((255,255,255))
        pygame.transform.scale(self.image, (51,51))

        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(self.maxWidtth)
        self.rect.y = random.randrange(self.maxHeight)

    def changeToBoom(self):
        centerPos = self.rect.center
        self.image = Bomb.boom_img
        self.image.set_colorkey((255,255,255))

        self.rect = self.image.get_rect()
        self.rect.center = centerPos

class Game():
    def __init__(self) -> None:
        self.mainSurface: pygame.surface.Surface = pygame.display.set_mode((500, 500))
        self.mainSurface.fill((255, 255, 255))
        self.renderList = pygame.sprite.Group()
        self.LoadBombGame()

    def addToRender(self, object):
        self.renderList.add(object)

    def render(self):
        self.mainSurface.fill((255, 255, 255))
        self.renderList.draw(self.mainSurface)
        pygame.display.flip()

    def LoadBombGame(self):
        for i in range(20):
            self.renderList.add(Bomb())

    def click(self, mousePos):
        for i in self.renderList:
            if i.rect.collidepoint(mousePos):
                i.changeToBoom()

    def gameCycle(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.click(event.pos)
            self.render()

game = Game()
game.gameCycle()
